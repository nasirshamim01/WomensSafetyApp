package com.darkness.WSafety;

public interface MyOnClickListener {
    void onItemClicked(int position);
}
